interface PaymentMethod {
    fun pay(fee: Double): Boolean
}